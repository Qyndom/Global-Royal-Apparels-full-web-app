import { createFileRoute } from '@tanstack/react-router'
import { useState } from 'react'
import { getProducts, addProduct, deleteProduct, type Product } from '../../server/products.functions'
import { verifyAdminPassword } from '../../server/admin.functions'
import { useServerFn } from '@tanstack/react-start'

export const Route = createFileRoute('/admin/')({
  loader: async () => {
    const products = await getProducts()
    return { products }
  },
  component: AdminPage,
})

function AdminLogin({ onSuccess }: { onSuccess: () => void }) {
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)
  const verify = useServerFn(verifyAdminPassword)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError('')
    try {
      const result = await verify({ data: { password } })
      if (result.success) {
        sessionStorage.setItem('rga-admin-auth', 'true')
        onSuccess()
      } else {
        setError('Incorrect password. Please try again.')
      }
    } catch {
      setError('An error occurred. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-black flex items-center justify-center px-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <img src="/logo.jpg" alt="RGA" className="h-20 w-20 rounded-full object-cover mx-auto mb-4 border-2 border-yellow-400" />
          <h1 className="text-3xl font-bold text-white">Admin Dashboard</h1>
          <p className="text-zinc-500 mt-2">Royal Global Apparel</p>
        </div>

        <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-8">
          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <label className="block text-zinc-400 text-sm mb-2">Admin Password</label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter admin password"
                required
                className="w-full bg-zinc-800 border border-zinc-700 text-white rounded-xl px-4 py-3 focus:outline-none focus:border-yellow-400 transition-colors"
              />
            </div>

            {error && (
              <div className="bg-red-900/40 border border-red-700 text-red-400 px-4 py-3 rounded-xl text-sm">
                {error}
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-yellow-400 text-black font-bold py-3.5 rounded-xl hover:bg-yellow-300 transition-colors disabled:opacity-60"
            >
              {loading ? 'Verifying...' : 'Login to Dashboard'}
            </button>
          </form>

          <div className="mt-6 pt-6 border-t border-zinc-800 text-center">
            <a href="/" className="text-zinc-500 text-sm hover:text-zinc-300 transition-colors">
              ← Back to Website
            </a>
          </div>
        </div>
      </div>
    </div>
  )
}

function AdminDashboard({ initialProducts }: { initialProducts: Product[] }) {
  const [products, setProducts] = useState(initialProducts)
  const [form, setForm] = useState({ name: '', category: '', price: '', image: '', description: '' })
  const [loading, setLoading] = useState(false)
  const [deleteId, setDeleteId] = useState<number | null>(null)
  const [tab, setTab] = useState<'products' | 'add'>('products')

  const addProductFn = useServerFn(addProduct)
  const deleteProductFn = useServerFn(deleteProduct)

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!form.name || !form.price) return
    setLoading(true)
    try {
      const updated = await addProductFn({ data: form })
      setProducts(updated)
      setForm({ name: '', category: '', price: '', image: '', description: '' })
      setTab('products')
    } finally {
      setLoading(false)
    }
  }

  const handleDelete = async (id: number) => {
    setDeleteId(id)
    try {
      const updated = await deleteProductFn({ data: { id } })
      setProducts(updated)
    } finally {
      setDeleteId(null)
    }
  }

  const handleLogout = () => {
    sessionStorage.removeItem('rga-admin-auth')
    window.location.reload()
  }

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Header */}
      <header className="bg-zinc-900 border-b border-zinc-800 px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <img src="/logo.jpg" alt="RGA" className="h-10 w-10 rounded-full object-cover" />
          <div>
            <h1 className="text-white font-bold">Admin Dashboard</h1>
            <p className="text-zinc-500 text-xs">Royal Global Apparel</p>
          </div>
        </div>
        <div className="flex gap-3">
          <a href="/" className="text-zinc-400 hover:text-white text-sm transition-colors">
            View Site
          </a>
          <button onClick={handleLogout} className="text-red-400 hover:text-red-300 text-sm transition-colors">
            Logout
          </button>
        </div>
      </header>

      {/* Stats */}
      <div className="max-w-6xl mx-auto px-6 py-8">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          {[
            { label: 'Total Products', value: products.length, color: 'text-yellow-400' },
            { label: 'Categories', value: [...new Set(products.map((p) => p.category))].length, color: 'text-green-400' },
            { label: 'WhatsApp', value: '08061265633', color: 'text-blue-400' },
            { label: 'Email', value: 'miraclenaya6', color: 'text-purple-400' },
          ].map((stat) => (
            <div key={stat.label} className="bg-zinc-900 border border-zinc-800 rounded-xl p-4">
              <p className="text-zinc-500 text-xs mb-1">{stat.label}</p>
              <p className={`${stat.color} font-bold text-lg truncate`}>{stat.value}</p>
            </div>
          ))}
        </div>

        {/* Tabs */}
        <div className="flex gap-2 mb-6">
          {(['products', 'add'] as const).map((t) => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className={`px-5 py-2.5 rounded-xl text-sm font-medium transition-colors ${
                tab === t ? 'bg-yellow-400 text-black' : 'bg-zinc-900 text-zinc-400 hover:text-white border border-zinc-800'
              }`}
            >
              {t === 'products' ? `Products (${products.length})` : '+ Add Product'}
            </button>
          ))}
        </div>

        {/* Products Tab */}
        {tab === 'products' && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {products.map((product) => (
              <div key={product.id} className="bg-zinc-900 border border-zinc-800 rounded-xl overflow-hidden">
                {product.image && (
                  <img src={product.image} alt={product.name} className="w-full h-44 object-cover" />
                )}
                <div className="p-4">
                  <div className="flex items-start justify-between gap-2 mb-1">
                    <h3 className="text-white font-semibold text-sm">{product.name}</h3>
                    <span className="bg-yellow-400/20 text-yellow-400 text-xs px-2 py-0.5 rounded-full flex-shrink-0">
                      {product.category}
                    </span>
                  </div>
                  <p className="text-zinc-500 text-xs mb-3 line-clamp-2">{product.description}</p>
                  <div className="flex items-center justify-between">
                    <span className="text-yellow-400 font-bold">{product.price}</span>
                    <button
                      onClick={() => handleDelete(product.id)}
                      disabled={deleteId === product.id}
                      className="text-red-400 hover:text-red-300 text-xs border border-red-900 px-3 py-1 rounded-lg transition-colors disabled:opacity-50"
                    >
                      {deleteId === product.id ? 'Deleting...' : 'Delete'}
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Add Product Tab */}
        {tab === 'add' && (
          <div className="max-w-xl">
            <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-6">
              <h2 className="text-white font-bold text-xl mb-6">Add New Product</h2>
              <form onSubmit={handleAdd} className="space-y-4">
                <div>
                  <label className="block text-zinc-400 text-sm mb-1.5">Product Name *</label>
                  <input
                    type="text"
                    required
                    value={form.name}
                    onChange={(e) => setForm({ ...form, name: e.target.value })}
                    placeholder="e.g. Luxury Evening Gown"
                    className="w-full bg-zinc-800 border border-zinc-700 text-white rounded-xl px-4 py-3 focus:outline-none focus:border-yellow-400 transition-colors"
                  />
                </div>
                <div>
                  <label className="block text-zinc-400 text-sm mb-1.5">Category</label>
                  <select
                    value={form.category}
                    onChange={(e) => setForm({ ...form, category: e.target.value })}
                    className="w-full bg-zinc-800 border border-zinc-700 text-white rounded-xl px-4 py-3 focus:outline-none focus:border-yellow-400 transition-colors"
                  >
                    <option value="">Select category</option>
                    {['Gowns', 'Asoebi', 'Office Wear', 'Traditional', 'Accessories', 'Footwear', 'Handbags'].map((c) => (
                      <option key={c}>{c}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-zinc-400 text-sm mb-1.5">Price *</label>
                  <input
                    type="text"
                    required
                    value={form.price}
                    onChange={(e) => setForm({ ...form, price: e.target.value })}
                    placeholder="e.g. ₦85,000"
                    className="w-full bg-zinc-800 border border-zinc-700 text-white rounded-xl px-4 py-3 focus:outline-none focus:border-yellow-400 transition-colors"
                  />
                </div>
                <div>
                  <label className="block text-zinc-400 text-sm mb-1.5">Image URL</label>
                  <input
                    type="url"
                    value={form.image}
                    onChange={(e) => setForm({ ...form, image: e.target.value })}
                    placeholder="https://..."
                    className="w-full bg-zinc-800 border border-zinc-700 text-white rounded-xl px-4 py-3 focus:outline-none focus:border-yellow-400 transition-colors"
                  />
                </div>
                <div>
                  <label className="block text-zinc-400 text-sm mb-1.5">Description</label>
                  <textarea
                    rows={3}
                    value={form.description}
                    onChange={(e) => setForm({ ...form, description: e.target.value })}
                    placeholder="Brief product description..."
                    className="w-full bg-zinc-800 border border-zinc-700 text-white rounded-xl px-4 py-3 focus:outline-none focus:border-yellow-400 transition-colors resize-none"
                  />
                </div>
                <button
                  type="submit"
                  disabled={loading}
                  className="w-full bg-yellow-400 text-black font-bold py-3.5 rounded-xl hover:bg-yellow-300 transition-colors disabled:opacity-60"
                >
                  {loading ? 'Adding Product...' : 'Add Product'}
                </button>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

function AdminPage() {
  const { products } = Route.useLoaderData()
  const [isAuthenticated, setIsAuthenticated] = useState(() => {
    if (typeof window !== 'undefined') {
      return sessionStorage.getItem('rga-admin-auth') === 'true'
    }
    return false
  })

  if (!isAuthenticated) {
    return <AdminLogin onSuccess={() => setIsAuthenticated(true)} />
  }

  return <AdminDashboard initialProducts={products} />
}

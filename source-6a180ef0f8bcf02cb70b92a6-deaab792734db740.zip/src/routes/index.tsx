import { createFileRoute } from '@tanstack/react-router'
import { useState, useEffect, useCallback } from 'react'
import { getProducts, type Product } from '../server/products.functions'

export const Route = createFileRoute('/')({
  loader: async () => {
    const products = await getProducts()
    return { products }
  },
  component: HomePage,
})

const testimonials = [
  {
    name: 'Chidinma Okafor',
    tribe: 'Igbo — Anambra State',
    avatar: 'CO',
    text: "Royal Global Apparel is simply the best! I bought my asoebi for my sister's wedding here and everyone couldn't stop asking where I got it. The quality is outstanding and the price is very fair. Ndi Igbo know quality!",
    rating: 5,
  },
  {
    name: 'Fatima Abdullahi',
    tribe: 'Hausa — Kano State',
    avatar: 'FA',
    text: "Wallahi, this shop is a blessing! I travelled from Kano to Onitsha and it was worth every kilometer. The evening gowns are beautiful and the customer service is excellent. I will keep coming back, insha Allah.",
    rating: 5,
  },
  {
    name: 'Adunola Fashola',
    tribe: 'Yoruba — Lagos State',
    avatar: 'AF',
    text: "Mo juba Royal Global Apparel! I ordered the office wear collection and I've received compliments every single day at work. The materials are premium, the stitching is perfect. These people know their craft!",
    rating: 5,
  },
  {
    name: 'Ngozi Efik-Williams',
    tribe: 'Efik — Cross River State',
    avatar: 'NE',
    text: "As an Efik woman who loves traditional and modern fashion, Royal Global Apparel gets it right every time. They combine elegance with cultural sensitivity. My traditional attire was a masterpiece!",
    rating: 5,
  },
  {
    name: 'Preye Amakiri',
    tribe: 'Ijaw — Bayelsa State',
    avatar: 'PA',
    text: "From the Delta, I found my go-to fashion brand. The handbags and footwear collection is premium quality at affordable prices. Royal Global Apparel understands the Nigerian woman perfectly!",
    rating: 5,
  },
  {
    name: 'Hauwa Musa',
    tribe: 'Fulani — Sokoto State',
    avatar: 'HM',
    text: "My daughter introduced me to Royal Global Apparel and I am grateful. The gowns here are modest yet very fashionable. Perfect for our events and celebrations. Excellent quality every time!",
    rating: 5,
  },
  {
    name: 'Blessing Ekpe',
    tribe: 'Ibibio — Akwa Ibom State',
    avatar: 'BE',
    text: "Royal Global Apparel made my traditional ceremony unforgettable. The Ibibio traditional attire they helped me pick was perfectly crafted. I am their customer for life. Highly recommended!",
    rating: 5,
  },
  {
    name: 'Sandra Ogban',
    tribe: 'Tiv — Benue State',
    avatar: 'SO',
    text: "Wonderful shop! I ordered the asoebi for my family reunion and everyone was thrilled. Beautiful colours, excellent quality, delivered on time. Royal Global Apparel exceeded my expectations!",
    rating: 5,
  },
]

function StarRating({ count }: { count: number }) {
  return (
    <div className="flex gap-0.5 mb-3">
      {Array.from({ length: count }).map((_, i) => (
        <span key={i} className="text-yellow-400 text-lg">★</span>
      ))}
    </div>
  )
}

function TestimonialsCarousel() {
  const [current, setCurrent] = useState(0)
  const total = testimonials.length

  const next = useCallback(() => setCurrent((c) => (c + 1) % total), [total])
  const prev = () => setCurrent((c) => (c - 1 + total) % total)

  useEffect(() => {
    const timer = setInterval(next, 5000)
    return () => clearInterval(timer)
  }, [next])

  const visible = [
    testimonials[current],
    testimonials[(current + 1) % total],
    testimonials[(current + 2) % total],
  ]

  return (
    <section className="py-20 bg-gradient-to-b from-zinc-900 to-black" id="testimonials">
      <div className="max-w-7xl mx-auto px-4">
        <div className="text-center mb-14">
          <span className="inline-block bg-yellow-400 text-black font-bold px-4 py-1.5 rounded-full text-sm uppercase tracking-widest mb-4">
            Customer Stories
          </span>
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">
            Loved Across Nigeria
          </h2>
          <p className="text-zinc-400 text-lg max-w-2xl mx-auto">
            From the North to the South, women across every tribe trust Royal Global Apparel for their finest moments.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {visible.map((t, i) => (
            <div
              key={`${current}-${i}`}
              className={`bg-zinc-800/80 border border-zinc-700 rounded-2xl p-6 transition-all duration-500 ${i === 1 ? 'md:scale-105 border-yellow-400/50' : ''}`}
            >
              <StarRating count={t.rating} />
              <p className="text-zinc-300 italic text-sm leading-relaxed mb-6">"{t.text}"</p>
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 rounded-full bg-yellow-400 flex items-center justify-center text-black font-bold text-sm flex-shrink-0">
                  {t.avatar}
                </div>
                <div>
                  <p className="text-white font-semibold text-sm">{t.name}</p>
                  <p className="text-yellow-400 text-xs">{t.tribe}</p>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="flex justify-center items-center gap-4 mt-10">
          <button
            onClick={prev}
            className="w-10 h-10 rounded-full border border-zinc-600 text-white hover:border-yellow-400 hover:text-yellow-400 transition-colors flex items-center justify-center"
          >
            ‹
          </button>
          <div className="flex gap-2">
            {testimonials.map((_, i) => (
              <button
                key={i}
                onClick={() => setCurrent(i)}
                className={`w-2 h-2 rounded-full transition-all ${i === current ? 'bg-yellow-400 w-6' : 'bg-zinc-600'}`}
              />
            ))}
          </div>
          <button
            onClick={next}
            className="w-10 h-10 rounded-full border border-zinc-600 text-white hover:border-yellow-400 hover:text-yellow-400 transition-colors flex items-center justify-center"
          >
            ›
          </button>
        </div>
      </div>
    </section>
  )
}

function encode(data: Record<string, string>) {
  return Object.entries(data)
    .map(([k, v]) => `${encodeURIComponent(k)}=${encodeURIComponent(v)}`)
    .join('&')
}

function OrderForm() {
  const [fields, setFields] = useState({
    name: '',
    email: '',
    phone: '',
    product: '',
    size: '',
    color: '',
    quantity: '1',
    message: '',
  })
  const [submitted, setSubmitted] = useState(false)
  const [loading, setLoading] = useState(false)

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFields({ ...fields, [e.target.name]: e.target.value })
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    try {
      await fetch('/order-form.html', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: encode({ 'form-name': 'order', ...fields }),
      })
      setSubmitted(true)
    } catch {
      setSubmitted(true)
    } finally {
      setLoading(false)
    }
  }

  if (submitted) {
    return (
      <div className="text-center py-16">
        <div className="text-6xl mb-4">🎉</div>
        <h3 className="text-3xl font-bold text-white mb-3">Order Received!</h3>
        <p className="text-zinc-400 text-lg max-w-md mx-auto">
          Thank you for your order! We will contact you within 24 hours to confirm your details.
        </p>
        <a
          href="https://wa.me/2348061265633"
          target="_blank"
          rel="noreferrer"
          className="inline-block mt-6 bg-green-500 text-white px-8 py-3 rounded-full font-bold hover:bg-green-600 transition-colors"
        >
          WhatsApp Us Directly
        </a>
      </div>
    )
  }

  return (
    <form onSubmit={handleSubmit} className="max-w-2xl mx-auto">
      <input type="hidden" name="form-name" value="order" />
      <input type="hidden" name="bot-field" />

      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        <div>
          <label className="block text-zinc-400 text-sm mb-2">Full Name *</label>
          <input
            type="text"
            name="name"
            required
            value={fields.name}
            onChange={handleChange}
            placeholder="Your full name"
            className="w-full bg-zinc-800 border border-zinc-700 text-white rounded-xl px-4 py-3 focus:outline-none focus:border-yellow-400 transition-colors"
          />
        </div>
        <div>
          <label className="block text-zinc-400 text-sm mb-2">Email Address *</label>
          <input
            type="email"
            name="email"
            required
            value={fields.email}
            onChange={handleChange}
            placeholder="your@email.com"
            className="w-full bg-zinc-800 border border-zinc-700 text-white rounded-xl px-4 py-3 focus:outline-none focus:border-yellow-400 transition-colors"
          />
        </div>
        <div>
          <label className="block text-zinc-400 text-sm mb-2">Phone Number *</label>
          <input
            type="tel"
            name="phone"
            required
            value={fields.phone}
            onChange={handleChange}
            placeholder="08012345678"
            className="w-full bg-zinc-800 border border-zinc-700 text-white rounded-xl px-4 py-3 focus:outline-none focus:border-yellow-400 transition-colors"
          />
        </div>
        <div>
          <label className="block text-zinc-400 text-sm mb-2">Product / Item *</label>
          <input
            type="text"
            name="product"
            required
            value={fields.product}
            onChange={handleChange}
            placeholder="e.g. Evening Gown, Asoebi..."
            className="w-full bg-zinc-800 border border-zinc-700 text-white rounded-xl px-4 py-3 focus:outline-none focus:border-yellow-400 transition-colors"
          />
        </div>
        <div>
          <label className="block text-zinc-400 text-sm mb-2">Size</label>
          <select
            name="size"
            value={fields.size}
            onChange={handleChange}
            className="w-full bg-zinc-800 border border-zinc-700 text-white rounded-xl px-4 py-3 focus:outline-none focus:border-yellow-400 transition-colors"
          >
            <option value="">Select size</option>
            <option>XS</option>
            <option>S</option>
            <option>M</option>
            <option>L</option>
            <option>XL</option>
            <option>XXL</option>
            <option>XXXL</option>
            <option>Custom Size</option>
          </select>
        </div>
        <div>
          <label className="block text-zinc-400 text-sm mb-2">Preferred Color</label>
          <input
            type="text"
            name="color"
            value={fields.color}
            onChange={handleChange}
            placeholder="e.g. Red, Navy Blue, Gold..."
            className="w-full bg-zinc-800 border border-zinc-700 text-white rounded-xl px-4 py-3 focus:outline-none focus:border-yellow-400 transition-colors"
          />
        </div>
        <div>
          <label className="block text-zinc-400 text-sm mb-2">Quantity</label>
          <input
            type="number"
            name="quantity"
            min="1"
            value={fields.quantity}
            onChange={handleChange}
            className="w-full bg-zinc-800 border border-zinc-700 text-white rounded-xl px-4 py-3 focus:outline-none focus:border-yellow-400 transition-colors"
          />
        </div>
        <div className="md:col-span-2">
          <label className="block text-zinc-400 text-sm mb-2">Additional Notes</label>
          <textarea
            name="message"
            value={fields.message}
            onChange={handleChange}
            rows={4}
            placeholder="Special requests, delivery address, or any other details..."
            className="w-full bg-zinc-800 border border-zinc-700 text-white rounded-xl px-4 py-3 focus:outline-none focus:border-yellow-400 transition-colors resize-none"
          />
        </div>
      </div>

      <button
        type="submit"
        disabled={loading}
        className="w-full mt-6 bg-yellow-400 text-black font-bold py-4 rounded-xl hover:bg-yellow-300 transition-colors disabled:opacity-60 text-lg"
      >
        {loading ? 'Sending Order...' : 'Place Order →'}
      </button>
    </form>
  )
}

function ProductCard({ product }: { product: Product }) {
  return (
    <div className="bg-zinc-900 border border-zinc-800 rounded-2xl overflow-hidden group hover:border-yellow-400/50 transition-all duration-300">
      <div className="relative overflow-hidden h-72">
        <img
          src={product.image}
          alt={product.name}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
        />
        <div className="absolute top-3 left-3">
          <span className="bg-yellow-400 text-black text-xs font-bold px-3 py-1 rounded-full">
            {product.category}
          </span>
        </div>
      </div>
      <div className="p-5">
        <h3 className="text-white font-bold text-lg mb-1">{product.name}</h3>
        <p className="text-zinc-400 text-sm mb-4 line-clamp-2">{product.description}</p>
        <div className="flex items-center justify-between">
          <span className="text-yellow-400 font-bold text-xl">{product.price}</span>
          <a
            href={`https://wa.me/2348061265633?text=I want to order ${encodeURIComponent(product.name)}`}
            target="_blank"
            rel="noreferrer"
            className="bg-yellow-400 text-black px-4 py-2 rounded-full text-sm font-bold hover:bg-yellow-300 transition-colors"
          >
            Order Now
          </a>
        </div>
      </div>
    </div>
  )
}

function HomePage() {
  const { products } = Route.useLoaderData()
  const [menuOpen, setMenuOpen] = useState(false)

  const navLinks = [
    { href: '#products', label: 'Products' },
    { href: '#about', label: 'About' },
    { href: '#testimonials', label: 'Reviews' },
    { href: '#order', label: 'Order' },
    { href: '#contact', label: 'Contact' },
  ]

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-black/90 backdrop-blur-sm border-b border-zinc-800">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
          <a href="/" className="flex items-center gap-3">
            <img src="/logo.jpg" alt="Royal Global Apparel" className="h-12 w-12 rounded-full object-cover" />
            <div className="hidden sm:block">
              <p className="text-yellow-400 font-bold text-sm leading-tight">Royal Global</p>
              <p className="text-white text-xs leading-tight">Apparel</p>
            </div>
          </a>

          {/* Desktop nav */}
          <div className="hidden md:flex items-center gap-6">
            {navLinks.map((l) => (
              <a key={l.href} href={l.href} className="text-zinc-400 hover:text-yellow-400 transition-colors text-sm font-medium">
                {l.label}
              </a>
            ))}
          </div>

          <div className="flex items-center gap-3">
            <a
              href="https://wa.me/2348061265633"
              target="_blank"
              rel="noreferrer"
              className="bg-yellow-400 text-black px-4 py-2 rounded-full text-sm font-bold hover:bg-yellow-300 transition-colors"
            >
              WhatsApp
            </a>
            <button
              onClick={() => setMenuOpen(!menuOpen)}
              className="md:hidden text-white p-1"
            >
              {menuOpen ? '✕' : '☰'}
            </button>
          </div>
        </div>

        {/* Mobile menu */}
        {menuOpen && (
          <div className="md:hidden bg-black border-t border-zinc-800 px-4 py-4 flex flex-col gap-4">
            {navLinks.map((l) => (
              <a
                key={l.href}
                href={l.href}
                onClick={() => setMenuOpen(false)}
                className="text-zinc-300 hover:text-yellow-400 transition-colors font-medium"
              >
                {l.label}
              </a>
            ))}
          </div>
        )}
      </nav>

      {/* Hero */}
      <section className="relative min-h-screen flex items-center pt-20" id="home">
        <div className="absolute inset-0 z-0">
          <img
            src="https://images.unsplash.com/photo-1529139574466-a303027c1d8b?q=80&w=1600&auto=format&fit=crop"
            alt="Fashion"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-black via-black/70 to-transparent" />
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 py-20">
          <div className="max-w-xl">
            <div className="flex items-center gap-3 mb-6">
              <img src="/logo.jpg" alt="RGA" className="h-16 w-16 rounded-full object-cover border-2 border-yellow-400" />
              <span className="bg-yellow-400 text-black font-bold px-4 py-1.5 rounded-full text-sm uppercase tracking-widest">
                Premium Fashion
              </span>
            </div>

            <h1 className="text-5xl md:text-6xl font-extrabold leading-tight mb-4">
              Royal Global<br />
              <span className="text-yellow-400">Apparel</span>
            </h1>

            <p className="text-zinc-300 text-lg mb-3">
              Dealers in all kinds of ladies wear
            </p>
            <p className="text-zinc-400 mb-8">
              Premium gowns, asoebi, handbags, heels, office wears & accessories.
              Located at Shop No C1 & C18, Winners Plaza, Main Market Onitsha.
            </p>

            <div className="flex flex-wrap gap-4">
              <a
                href="#order"
                className="bg-yellow-400 text-black px-7 py-3.5 rounded-full font-bold hover:bg-yellow-300 transition-colors text-base"
              >
                Place an Order
              </a>
              <a
                href="https://wa.me/2348061265633"
                target="_blank"
                rel="noreferrer"
                className="border border-yellow-400 text-yellow-400 px-7 py-3.5 rounded-full font-bold hover:bg-yellow-400/10 transition-colors text-base"
              >
                WhatsApp Us
              </a>
            </div>

            <div className="flex gap-8 mt-10">
              {[['500+', 'Happy Customers'], ['200+', 'Products'], ['5★', 'Rating']].map(([num, label]) => (
                <div key={label}>
                  <p className="text-yellow-400 text-2xl font-bold">{num}</p>
                  <p className="text-zinc-500 text-sm">{label}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Products */}
      <section className="py-20 bg-zinc-950" id="products">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-14">
            <span className="inline-block bg-yellow-400 text-black font-bold px-4 py-1.5 rounded-full text-sm uppercase tracking-widest mb-4">
              Our Collection
            </span>
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">Featured Products</h2>
            <p className="text-zinc-400 text-lg max-w-2xl mx-auto">
              Explore our curated collection of premium women's fashion from the heart of Onitsha Main Market.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {products.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>

          <div className="text-center mt-12">
            <a
              href="https://wa.me/2348061265633?text=Hello! I would like to see your full collection"
              target="_blank"
              rel="noreferrer"
              className="inline-block border border-yellow-400 text-yellow-400 px-8 py-3.5 rounded-full font-bold hover:bg-yellow-400 hover:text-black transition-colors"
            >
              View Full Collection on WhatsApp →
            </a>
          </div>
        </div>
      </section>

      {/* About */}
      <section className="py-20 bg-black" id="about">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div>
              <span className="inline-block bg-yellow-400 text-black font-bold px-4 py-1.5 rounded-full text-sm uppercase tracking-widest mb-6">
                About Us
              </span>
              <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
                Nigeria's Premier<br />Female Fashion Brand
              </h2>
              <p className="text-zinc-400 text-lg leading-relaxed mb-6">
                Royal Global Apparel was founded with a singular vision: to make luxury women's fashion accessible to every Nigerian woman, regardless of her tribe or location. Based at the heart of Onitsha Main Market — one of the largest markets in West Africa — we serve customers from all 36 states of Nigeria.
              </p>
              <p className="text-zinc-400 leading-relaxed mb-8">
                From elegant evening gowns to traditional asoebi, sophisticated office wear to premium accessories, our collection celebrates the beauty and diversity of the Nigerian woman. We source only the finest materials and work with skilled artisans to deliver fashion that speaks quality.
              </p>

              <div className="grid grid-cols-2 gap-6 mb-8">
                {[
                  { icon: '👗', title: 'Premium Quality', desc: 'Only the finest fabrics and craftsmanship' },
                  { icon: '🚚', title: 'Nationwide Delivery', desc: 'We deliver to all 36 states' },
                  { icon: '💰', title: 'Best Prices', desc: 'Factory prices direct to you' },
                  { icon: '🤝', title: 'Trusted Brand', desc: '500+ satisfied customers & counting' },
                ].map((item) => (
                  <div key={item.title} className="flex gap-3">
                    <span className="text-2xl">{item.icon}</span>
                    <div>
                      <p className="text-white font-semibold text-sm">{item.title}</p>
                      <p className="text-zinc-500 text-xs">{item.desc}</p>
                    </div>
                  </div>
                ))}
              </div>

              <div className="flex flex-wrap gap-4">
                <a
                  href="#order"
                  className="bg-yellow-400 text-black px-6 py-3 rounded-full font-bold hover:bg-yellow-300 transition-colors"
                >
                  Shop Now
                </a>
                <a
                  href="https://wa.me/2348061265633"
                  target="_blank"
                  rel="noreferrer"
                  className="border border-zinc-700 text-zinc-300 px-6 py-3 rounded-full font-bold hover:border-yellow-400 hover:text-yellow-400 transition-colors"
                >
                  Chat with Us
                </a>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <img
                src="https://images.unsplash.com/photo-1581338834647-b0fb40704e21?q=80&w=600&auto=format&fit=crop"
                alt="Fashion collection"
                className="rounded-2xl object-cover h-64 w-full"
              />
              <img
                src="https://images.unsplash.com/photo-1509631179647-0177331693ae?q=80&w=600&auto=format&fit=crop"
                alt="Traditional wear"
                className="rounded-2xl object-cover h-64 w-full mt-8"
              />
              <img
                src="https://images.unsplash.com/photo-1496747611176-843222e1e57c?q=80&w=600&auto=format&fit=crop"
                alt="Evening gown"
                className="rounded-2xl object-cover h-64 w-full"
              />
              <div className="bg-yellow-400 rounded-2xl flex flex-col items-center justify-center h-64 mt-8">
                <img src="/logo.jpg" alt="RGA Logo" className="w-24 h-24 rounded-full object-cover mb-3" />
                <p className="text-black font-bold text-center text-sm px-4">Royal Global Apparel</p>
                <p className="text-black/70 text-xs text-center px-4">Dealers in all kinds of ladies wear</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <TestimonialsCarousel />

      {/* Order Form */}
      <section className="py-20 bg-zinc-950" id="order">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-14">
            <span className="inline-block bg-yellow-400 text-black font-bold px-4 py-1.5 rounded-full text-sm uppercase tracking-widest mb-4">
              Place an Order
            </span>
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">
              Order Your Fashion
            </h2>
            <p className="text-zinc-400 text-lg max-w-2xl mx-auto">
              Fill the form below and we'll reach out to confirm your order within 24 hours.
              You can also order directly on WhatsApp for faster response.
            </p>
          </div>

          <OrderForm />

          <div className="text-center mt-8">
            <p className="text-zinc-500 text-sm">
              Prefer to order directly?{' '}
              <a href="https://wa.me/2348061265633" target="_blank" rel="noreferrer" className="text-yellow-400 hover:underline">
                Chat on WhatsApp
              </a>{' '}
              or call{' '}
              <a href="tel:+2348061265633" className="text-yellow-400 hover:underline">08061265633</a>
            </p>
          </div>
        </div>
      </section>

      {/* Contact */}
      <section className="py-16 bg-black border-t border-zinc-800" id="contact">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
            <div>
              <img src="/logo.jpg" alt="Royal Global Apparel" className="h-16 w-16 rounded-full object-cover mb-4" />
              <h3 className="text-white font-bold text-xl mb-2">Royal Global Apparel</h3>
              <p className="text-zinc-500 text-sm">Dealers in all kinds of ladies wear. Serving Nigeria with premium fashion.</p>
            </div>
            <div>
              <h4 className="text-yellow-400 font-bold mb-4 uppercase text-sm tracking-wider">Location</h4>
              <p className="text-zinc-400 text-sm leading-relaxed">
                Shop No C1 & C18<br />
                Winners Plaza, Biafra Market<br />
                Main Market, Onitsha<br />
                Anambra State, Nigeria
              </p>
            </div>
            <div>
              <h4 className="text-yellow-400 font-bold mb-4 uppercase text-sm tracking-wider">Contact</h4>
              <div className="space-y-2">
                <p className="text-zinc-400 text-sm">📱 08061265633</p>
                <p className="text-zinc-400 text-sm">📱 09037325861</p>
                <p className="text-zinc-400 text-sm">✉️ miraclenaya6@gmail.com</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-zinc-950 border-t border-zinc-800 py-6 text-center">
        <p className="text-zinc-600 text-sm">
          © {new Date().getFullYear()} Royal Global Apparel. All rights reserved.
        </p>
        <a href="/admin" className="text-zinc-800 text-xs hover:text-zinc-600 transition-colors mt-1 inline-block">
          Admin
        </a>
      </footer>
    </div>
  )
}
